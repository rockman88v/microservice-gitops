{{/*
Base name for this chart's resources, honoring nameOverride.
*/}}
{{- define "microservice-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name, prefixed with release name unless it already contains it.
*/}}
{{- define "microservice-chart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "microservice-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "microservice-chart.labels" -}}
helm.sh/chart: {{ include "microservice-chart.chart" . }}
{{ include "microservice-chart.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end -}}

{{/*
Selector labels — scoped to this release, used as podSelector everywhere
(Service, NetworkPolicy, PDB, HPA) so that two releases of this chart never collide.
*/}}
{{- define "microservice-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "microservice-chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "microservice-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "microservice-chart.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Service name used by StatefulSet's spec.serviceName (and as the Service object name).
*/}}
{{- define "microservice-chart.serviceName" -}}
{{- if .Values.statefulset.serviceName -}}
{{ .Values.statefulset.serviceName }}
{{- else -}}
{{ include "microservice-chart.fullname" . }}-headless
{{- end -}}
{{- end -}}

{{/*
Name of the Service object backing this release — headless for statefulset, regular otherwise.
Used by both service.yaml and ingress.yaml so they always agree on the backend name.
*/}}
{{- define "microservice-chart.svcName" -}}
{{- if eq .Values.workloadType "statefulset" -}}
{{ include "microservice-chart.serviceName" . }}
{{- else -}}
{{ include "microservice-chart.fullname" . }}
{{- end -}}
{{- end -}}

{{/*
Fail fast on invalid/incompatible values instead of producing a broken manifest.
*/}}
{{- define "microservice-chart.validateValues" -}}
{{- if not (has .Values.workloadType (list "deployment" "statefulset")) -}}
{{ fail (printf "workloadType must be 'deployment' or 'statefulset', got %q" .Values.workloadType) }}
{{- end -}}
{{- if and .Values.autoscaling.enabled (eq .Values.workloadType "statefulset") -}}
{{ fail "autoscaling.enabled=true is not supported when workloadType=statefulset" }}
{{- end -}}
{{- if .Values.service.nodePort -}}
{{- if eq .Values.workloadType "statefulset" -}}
{{ fail "service.nodePort is not supported when workloadType=statefulset (headless Service has no nodePort)" }}
{{- end -}}
{{- if not (has .Values.service.type (list "NodePort" "LoadBalancer")) -}}
{{ fail (printf "service.nodePort requires service.type to be NodePort or LoadBalancer, got %q" .Values.service.type) }}
{{- end -}}
{{- end -}}
{{- if .Values.podDisruptionBudget.enabled -}}
{{- if and .Values.podDisruptionBudget.minAvailable .Values.podDisruptionBudget.maxUnavailable -}}
{{ fail "podDisruptionBudget: set only one of minAvailable or maxUnavailable, not both" }}
{{- end -}}
{{- if not .Values.podDisruptionBudget.maxUnavailable -}}
{{- $effectiveReplicas := .Values.replicaCount -}}
{{- if and (eq .Values.workloadType "deployment") .Values.autoscaling.enabled -}}
{{- $effectiveReplicas = .Values.autoscaling.minReplicas -}}
{{- end -}}
{{- $minAvailable := .Values.podDisruptionBudget.minAvailable | toString -}}
{{- if regexMatch "^[0-9]+$" $minAvailable -}}
{{- if ge (int $minAvailable) (int $effectiveReplicas) -}}
{{ fail (printf "podDisruptionBudget.minAvailable (%v) >= effective replica count (%v) blocks all voluntary eviction/node drain; lower it or use maxUnavailable instead" $minAvailable $effectiveReplicas) }}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
envFrom entries for every existingSecrets[].name — mounts the entire secret as env vars.
*/}}
{{- define "microservice-chart.envFromExistingSecrets" -}}
{{- range .Values.existingSecrets }}
- secretRef:
    name: {{ .name }}
{{- end -}}
{{- end -}}
